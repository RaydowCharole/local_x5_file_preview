package com.tencent.tbs.demo.utils;

public interface WebViewJavaScriptFunction {

	void onJsFunctionCalled(String tag);
}
