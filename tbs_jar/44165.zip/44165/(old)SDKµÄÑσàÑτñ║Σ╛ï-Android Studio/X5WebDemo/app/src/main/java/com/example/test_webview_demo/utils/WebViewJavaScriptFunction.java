package com.example.test_webview_demo.utils;

public interface WebViewJavaScriptFunction {

	void onJsFunctionCalled(String tag);
}
